package main

import (
	"crypto/rand"
	"encoding/hex"
	"fmt"
	"github.com/tjfoc/gmsm/sm2"
	"github.com/tjfoc/gmsm/sm3"
	"github.com/tjfoc/gmsm/sm4"
	"github.com/tjfoc/gmsm/x509"
	"io/ioutil"
	"math/big"
	"os"
	"strings"
)

type Request struct {
	SKey string
	Body string
	Sign string
}

func main() {
	//cc()
	//dd()

	//genKey()

	//encode()
	//decode()

	//signTest()

	test()
}

func test() {
	public := "807FDDA616D72F793F0FA6E6B0A7D0AED040AE397E095A96620F37989715342F11C5059939BEDC7D5AE4075AB57BF66D15FE3FD80EF05CD608B67432E3A837B2"
	private := "86708055647511838840975032829443234242240665917318252570018371729445982555637"
	fmt.Printf("公钥: %s\n", public)
	fmt.Printf("私钥: %s\n", private)

	req := encode(public)

	fmt.Println("加密结果:")
	fmt.Printf("skey: %s\n", req.SKey)
	fmt.Printf("sign: %s\n", req.Sign)
	fmt.Printf("body: %s\n", req.Body)

	fmt.Println("解密结果:")
	decode(private, req)
}

func signTest() {
	msg := []byte(`{"respHeader":{"retCode":"0","traceSerial":"788646546"}}`)
	sign := GenSign(msg)

	//privateKey, err := x509.ReadPrivateKeyFromHex("CFE96E071C65A694AFF9ECCC3234AFC83183C65897616FBDD934682581113B42")
	//if err != nil {
	//	panic(err)
	//	return
	//}

	target := GenSign(msg)
	if target == sign {
		fmt.Println(true)
	} else {
		fmt.Println(false)
	}
	//signBytes, err := hex.DecodeString(sign)
	//verify := privateKey.Verify(msg, signBytes)
	//fmt.Println(verify)
}

func genKey() {
	key, _ := sm2.GenerateKey(nil)

	x := strings.ToUpper(fmt.Sprintf("%x", key.X))
	y := strings.ToUpper(fmt.Sprintf("%x", key.Y))
	//d := strings.ToUpper(fmt.Sprintf("%x", key.D))

	fmt.Printf("%s\n", x)
	fmt.Printf("%s\n", y)
	fmt.Printf("公钥： %s%s\n", x, y)
	//fmt.Printf("%s\n", d)

	fmt.Println("密钥： ", key.D.String())

	//pub := make([]byte, 100)
	//_, _ = key.ScalarMult(key.X, key.Y, pub)
	//fmt.Printf("%x\n", pub)
}

func javaByteToGoByte(src string) string {
	desc := make([]byte, 0)
	runes := []rune(src)
	for _, r := range runes {
		if r < -128 || r > 127 {
			return ""
		}
		if r < 0 {
			desc = append(desc, byte(256 + r))
		} else {
			desc = append(desc, byte(r))
		}
	}
	return string(desc)
}

func decode(privateKeyStr string, req *Request) {
	skey := req.SKey
	sign := req.Sign
	body := req.Body
	//skey := "307902210084ca4808599f47acf6debbcfcdeb0fc55f78aaf73e76cf1f84b642111e104c2c02201d45a1e135647fe97dca36d5b10aa0d68e75cb1e9667f3808ff2ac6d4587394d042053f4b2b019e42d438207dcd87afb2b722fac9e38df4ba2358cfbfda05943ad9d0410a13cb12ec84adb84ef7bf3efa7283ffe"
	//sign := "09fd44497ddf2d58edf28fe647c481d47dfbc46c647dbd8c762e7215e7713c07"
	//body := "b48c562271c9fbdc13da81943f60eb9f93c64ce789c1914e3e0091808fd6a2b16dcf33e9ba9290ed58de50308b35eeb116175eca7e7066fa25b6c5dde4eb1116646ec365a5e3385074dcfd6751de9e86c76360c994ddd5ba0949ce30593ebf4c2def368d53e4fb4a6a728daa0364707e8a5595c01ecb5da3fcb7f5322c57ff7a"

	//file, _ := os.Open("./priv.pem")
	//pubkeyPem, err := ioutil.ReadAll(file)
	//privateKey, err := x509.ReadPrivateKeyFromPem(pubkeyPem, nil)

	// 将十进制的密钥转成十六进制的密钥
	b := new(big.Int)
	bString, _ := b.SetString(privateKeyStr, 10)
	hexD := fmt.Sprintf("%x", bString)

	privateKey, err := x509.ReadPrivateKeyFromHex(hexD)
	if err != nil {
		panic(err)
	}

	decodeString, _ := hex.DecodeString(skey)
	sm4Key, err := privateKey.DecryptAsn1(decodeString)
	fmt.Println("sm4Key:", string(sm4Key))

	bodyBytes, err := hex.DecodeString(body)
	out, err := sm4.Sm4Ecb(sm4Key, bodyBytes, false)
	fmt.Printf("解密出来的报文: %s\n", out)

	target := GenSign(out)
	if target == sign {
		fmt.Println("签名检验结果: ", true)
	} else {
		fmt.Println("签名检验结果: ", false)
	}

	//signBytes, err := hex.DecodeString(sign)
	//verify := privateKey.Verify(out, signBytes)
	//fmt.Println(verify)
}

func encode(publicKeyStr string) *Request {
	//file, _ := os.Open("./pub.pem")
	//pemBytes, _ := ioutil.ReadAll(file)
	//publicKey, err := x509.ReadPublicKeyFromPem(pemBytes)
	publicKey, err := x509.ReadPublicKeyFromHex(publicKeyStr)
	if err != nil {
		panic(err)
	}

	msg := []byte(`{"respHeader":{"retCode":"0","traceSerial":"788646546","traceDate":"20220215","traceTime":"161800","retMsg":"成功"}}`)
	fmt.Printf("原始报文: %s\n", msg)
	// todo: 使用随机算法生成随机字符串
	//uuid, err := uuid.GenerateUUID()
	sm4Key := []byte("1234567890abcdef")
	fmt.Printf("sm4Key: %s\n", sm4Key)

	body := GenBody(msg, sm4Key)
	sign := GenSign(msg)
	skey := GenSkey(publicKey, sm4Key)

	return &Request{
		SKey: skey,
		Body: body,
		Sign: sign,
	}
}

func GenSkey(pub *sm2.PublicKey, sm4Key []byte) string {
	asn1, err := pub.EncryptAsn1(sm4Key, rand.Reader)
	if err != nil {
		return "err"
	}
	return fmt.Sprintf("%x", asn1)
}
func GenSign(msg []byte) string {
	h := sm3.New()
	h.Write(msg)
	sum := h.Sum(nil)
	return fmt.Sprintf("%x", sum)
}
func GenBody(msg []byte, sm4Key []byte) string {
	//iv := []byte("0000000000000000")
	//err = SetIV(iv)//设置SM4算法实现的IV值,不设置则使用默认值
	ecbMsg, err :=sm4.Sm4Ecb(sm4Key, msg, true)   //sm4Ecb模式pksc7填充加密
	if err != nil {
		fmt.Println(err)
		return ""
	}
	return fmt.Sprintf("%x", ecbMsg)
}

func dd() {
	file1, err := os.Open("./pub.pem")
	pubkeyPem, err := ioutil.ReadAll(file1)
	pubKey, err := x509.ReadPublicKeyFromPem(pubkeyPem) // 读取公钥
	if err != nil {
		fmt.Println(err)
		return
	}

	msg := []byte(`{"respHeader":{"retCode":"0","traceSerial":"788646546","traceDate":"20220215","traceTime":"161800","retMsg":"成功"}}`)

	asn1, err := pubKey.EncryptAsn1(msg, nil)
	fmt.Printf("加密结果:%x\n",asn1)
}

// 生成证书 保存到文件
func cc() {
	priv, err := sm2.GenerateKey(nil) // 生成密钥对
	if err != nil {
		fmt.Println(err)
		return
	}
	privPem, err := x509.WritePrivateKeyToPem(priv, nil) // 生成密钥文件
	if err != nil {
		fmt.Println(err)
		return
	}
	fmt.Println(privPem)
	file1, err := os.OpenFile("./priv.pem", os.O_WRONLY|os.O_APPEND, 0777)
	file1.Write(privPem)
	defer file1.Close()

	pubKey, _ := priv.Public().(*sm2.PublicKey)
	pubkeyPem, err := x509.WritePublicKeyToPem(pubKey)       // 生成公钥文件
	if err != nil {
		fmt.Println(err)
		return
	}
	fmt.Println(pubkeyPem)
	file2, err := os.OpenFile("./pub.pem", os.O_WRONLY|os.O_APPEND, 0777)
	n, err := file2.Write(pubkeyPem)
	if err != nil {
		fmt.Println("n:", n)
		fmt.Println("error:", err)
	}
	defer file2.Close()
}
